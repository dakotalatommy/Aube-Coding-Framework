import{j as s,b3 as t}from"./vendor-Btf92ww9.js";/* empty css                         */function r(){return s.jsx(t,{})}export{r as default};
