import{r as d,bH as N,ae as k,a7 as h,E as C,bI as y,Q as F,j as e,bJ as g,X as O,aP as u,aj as x,M as I,U as P,G as b,bK as R,ad as H,W as B}from"./vendor-IMSkG-L0.js";import{C as a,e as i,h as m,f as o,D as L,x as D,y as W,z as q,G as U,c as M,d as V}from"./index-FIPB03p9.js";import{S as z}from"./switch-CA-k9D7W.js";import{T as G,a as X,b as v,c as w}from"./tabs-mpmyhwwq.js";const p=[{id:1,name:"Welcome New Clients",description:"Send a warm welcome message and aftercare tips to new clients",icon:N,color:"bg-primary/5 border-primary/20",iconColor:"text-primary",active:!0,clients:23,status:"3 messages sent today",followUpDetails:{trigger:"New appointment completed",timeline:[{time:"2 hours after appointment",action:"Welcome message with aftercare tips",frequency:"Once",message:`Hi [Name]! 💕 Welcome to our beauty family! Thank you for choosing us for your [Service] today. Here are some aftercare tips to help you maintain your gorgeous new look:

✨ Avoid touching the area for 24 hours
✨ Use the gentle cleanser we discussed
✨ Apply the recommended moisturizer twice daily

If you have any questions, don't hesitate to reach out. We can't wait to see you again! 💖

XOXO,
[Your Business Name]`},{time:"24 hours later",action:"Check-in: 'How are you feeling?'",frequency:"Once",message:`Hey [Name]! 🌟 Just checking in - how are you feeling after your [Service] yesterday? We hope you're absolutely loving your new look!

Everything healing well? Any questions about your aftercare routine?

We'd love to hear how you're doing! Feel free to send us a selfie if you're loving the results 📸✨

Talk soon!
[Your Name]`},{time:"3 days later",action:"Satisfaction survey",frequency:"Once",message:`Hi [Name]! 💖 We hope you're still glowing from your recent [Service]! We'd love to hear about your experience with us.

Could you take 2 minutes to share your thoughts? Your feedback helps us keep providing amazing service to beautiful clients like you!

⭐ Rate Your Experience: [Survey Link]

As a thank you, here's a special 10% discount for your next appointment: THANKYOU10

With love,
[Your Business Name] ✨`},{time:"1 week later",action:"Follow-up appointment reminder",frequency:"Once",message:`Hello gorgeous! 🌸 It's been a week since your [Service] and we hope you're still feeling fabulous!

To keep you looking your absolute best, we recommend booking your next appointment in [Timeframe]. 

📅 Ready to book? Reply to this message or call us at [Phone]
💕 Mention this text for 15% off your next service!

We miss you already!
[Your Business Name]`}],totalTouchpoints:4,duration:"1 week"}},{id:2,name:"Check-in After Service",description:"Follow up 24 hours after appointments to ensure satisfaction",icon:k,color:"bg-accent/5 border-accent/20",iconColor:"text-accent",active:!0,clients:45,status:"2 check-ins pending",followUpDetails:{trigger:"Any appointment completed",timeline:[{time:"24 hours after appointment",action:"Care check-in message",frequency:"Every appointment",message:`Hi [Name]! 💕 How are you feeling 24 hours after your [Service]? We hope you're absolutely loving the results!

🌟 Any questions about your aftercare routine?
🌟 Everything feeling comfortable?
🌟 Need any product recommendations?

We're here if you need anything at all. Can't wait to hear how amazing you're feeling!

Love,
[Your Name] ✨`},{time:"48 hours later",action:"Photo request for before/after",frequency:"If positive response",message:`Hey beautiful! 📸 We're so thrilled you're loving your [Service]! 

Would you mind sharing a quick photo? We love celebrating our gorgeous clients and showcasing our work (with your permission, of course!).

✨ Send us your selfie and we might feature you on our page!
✨ Plus, photo submissions get 20% off their next service!

No pressure at all - we just love seeing happy, confident clients! 💖

[Your Business Name]`},{time:"1 week later",action:"Maintenance tips",frequency:"Once per client per month",message:`Hello lovely! 🌸 Your [Service] should be settling in beautifully by now!

Here are some pro tips to keep you looking flawless:

💡 [Specific maintenance tip 1]
💡 [Specific maintenance tip 2]
💡 [Specific maintenance tip 3]

Remember: great results come from great aftercare! You're doing amazing 💖

Need any products to help maintain your look? We've got you covered!

[Your Business Name]`}],totalTouchpoints:3,duration:"1 week"}},{id:3,name:"Birthday Surprises",description:"Send special birthday offers to celebrate your clients",icon:h,color:"bg-secondary/20 border-secondary/40",iconColor:"text-primary",active:!0,clients:156,status:"Next: Emma's birthday in 3 days",followUpDetails:{trigger:"Client birthday approaching",timeline:[{time:"1 week before birthday",action:"Birthday week announcement",frequency:"Annual",message:`🎉 IT'S ALMOST YOUR BIRTHDAY WEEK, [Name]! 🎉

We can't contain our excitement! Your special day is coming up on [Date] and we want to make sure you feel absolutely GORGEOUS! 💖

🎁 Something special is coming your way...
🎁 Stay tuned for your birthday surprise!
🎁 Get ready to be pampered like the queen you are!

Birthday glam session, anyone? 👑✨

With love,
[Your Business Name]`},{time:"3 days before birthday",action:"Special offer reminder",frequency:"Annual",message:`🎂 3 MORE DAYS until your birthday, gorgeous! 🎂

Your special surprise is here! 🎁

✨ 30% OFF any service during your birthday week!
✨ FREE add-on service worth $50+
✨ Complimentary birthday photoshoot
✨ Special birthday gift to take home!

Use code: BIRTHDAY30
Valid: [Date Range]

📞 Call now to book your birthday glam: [Phone]

Let's make your birthday week UNFORGETTABLE! 💕

[Your Business Name]`},{time:"On birthday",action:"Birthday wishes + discount code",frequency:"Annual",message:`🎉🎂 HAPPY BIRTHDAY [Name]! 🎂🎉

Today is YOUR day to shine even brighter than usual! ✨

We hope your day is filled with love, laughter, and all the beautiful moments you deserve! You bring so much joy to our salon family! 💖

🎁 Don't forget - your special birthday offer is still waiting:
• 30% OFF any service (Code: BIRTHDAY30)
• Valid through [End Date]

Treat yourself to something fabulous - you deserve it! 👑

Happy Birthday beautiful! 🌟

All our love,
[Your Business Name] Team`},{time:"3 days after birthday",action:"Last chance reminder",frequency:"Annual",message:`Hey birthday girl! 🎈 Hope you had the most AMAZING birthday!

Just a gentle reminder that your special birthday treat expires soon! 😱

⏰ Last chance to use your 30% OFF birthday discount!
⏰ Expires: [Date] (that's tomorrow!)
⏰ Code: BIRTHDAY30

Don't let this gorgeous opportunity slip away! You deserve to treat yourself after such a special celebration! 💕

📞 Quick booking: [Phone]
💻 Online: [Website]

We'd love to help you extend those birthday vibes! ✨

[Your Business Name]`}],totalTouchpoints:4,duration:"2 weeks"}},{id:4,name:"Book Next Appointment",description:"Service-specific reminders based on maintenance cycles",icon:C,color:"bg-primary/5 border-primary/20",iconColor:"text-primary",active:!1,clients:67,status:"Ready to activate",followUpDetails:{trigger:"Service-specific maintenance timing",timeline:[{time:"Service-dependent timing",action:"Optimal booking reminder",frequency:"Per service cycle",message:`**HAIR COLOR CLIENTS** (5 weeks after service):
Hi [Name]! ✨ Your gorgeous color will need a refresh soon! It's been about 5 weeks since your last appointment - perfect timing to book ahead and keep that beautiful color looking fresh! Reply YES for our next available slot.

**LASH EXTENSION CLIENTS** (10 days after service):
Hey beautiful [Name]! 👁️✨ Your lash fill is coming up soon! It's been about 10 days since your last appointment - perfect timing to book ahead and keep those lashes looking flawless! Reply YES to secure your spot.

**FACIAL CLIENTS** (3.5 weeks after service):
Hi [Name]! 🌟 It's been about 3.5 weeks since your last facial - perfect timing to book your next glow session ahead of time! Your skin will be ready for another dose of pampering soon. Reply YES to book!

**BARBER CLIENTS** (2 weeks after service):
What's up [Name]! ✂️ Your next trim is coming up soon! It's been about 2 weeks since your last cut - perfect timing to book ahead and stay looking sharp! Reply YES and I'll get you scheduled.

**NAIL CLIENTS** (10 days after service):
Hi [Name]! 💅✨ Your nails will need some love soon! It's been about 10 days since your last service - perfect timing to book your maintenance appointment before any chips or growth show. Reply YES to book this week.`},{time:"3-5 days later",action:"Incentive offer",frequency:"If no response",message:`Hey gorgeous [Name]! 🌸 Don't let your beautiful results fade!

Since it's the perfect time for your maintenance appointment, we wanted to make it extra special:

✨ 15% OFF your next service
✨ FREE add-on worth $25+
✨ Priority booking for your favorite time slots

Use code: MAINTAIN15
Valid for the next 7 days!

📞 Quick booking: [Phone]
💻 Online: [Website]

**Service-Specific Benefits:**
• Hair Color: Keep your color vibrant and rich
• Lashes: Maintain that full, dramatic look
• Facials: Continue your skin's transformation
• Barber: Stay sharp and professional
• Nails: Keep that flawless manicure

Let's keep you looking amazing! 💖

[Your Business Name]`},{time:"4 days later",action:"Final maintenance reminder",frequency:"Final opportunity",message:`Hi [Name] 💕 Just a gentle final reminder!

Your maintenance window is closing soon, and we'd hate for you to:

⚠️ Hair Color: Experience fading or root growth
⚠️ Lashes: Lose that full, beautiful look
⚠️ Facial: Miss your skin's optimal treatment cycle
⚠️ Barber: Let that sharp style grow out
⚠️ Nails: Deal with chips or overgrowth

Your 15% OFF offer (Code: MAINTAIN15) expires tomorrow!

🎯 We have same-day appointments available
🎯 Your favorite technician has openings
🎯 Perfect timing to stay looking flawless

No pressure at all - we just want you to keep feeling confident and beautiful! 🌟

With love,
[Your Business Name] Team ✨`}],totalTouchpoints:3,duration:"1-2 weeks (varies by service)"}},{id:5,name:"Ask for Reviews",description:"Request reviews from happy clients to grow your reputation",icon:y,color:"bg-accent/5 border-accent/20",iconColor:"text-accent",active:!0,clients:38,status:"5 reviews received this week",followUpDetails:{trigger:"Positive satisfaction response",timeline:[{time:"3 days after positive feedback",action:"Review request with direct links",frequency:"Once per client per year",message:`Hi [Name]! 💖 We're SO happy you loved your recent [Service]!

Your kind words mean the world to us! Would you mind sharing your experience online? It would help other beautiful people discover our salon! ✨

⭐ Quick 2-minute review:
📱 Google: [Google Link]
📱 Facebook: [Facebook Link]
📱 Yelp: [Yelp Link]

As a thank you for your time:
🎁 10% OFF your next appointment!

No pressure at all - we just appreciate you! 💕

[Your Business Name]`},{time:"1 week later",action:"Gentle review reminder",frequency:"If no review given",message:`Hey beautiful! 🌟 Just a gentle reminder about that review - no pressure at all!

If you have a spare minute and loved your [Service], we'd be so grateful for a quick review! Your words help other amazing people find us! 💕

⭐ Quick links:
• Google: [Link]
• Facebook: [Link]

And don't forget - you still have that 10% OFF waiting for your next visit! 🎁

Thank you for being such an amazing client!

[Your Business Name] ✨`},{time:"2 weeks later",action:"Referral program invitation",frequency:"For clients who left reviews",message:`Thank you SO much for your amazing review, [Name]! 🌟 You're absolutely wonderful!

Since you love sharing the love, we thought you'd be perfect for our VIP Referral Program! 💎

✨ How it works:
• Refer a friend → You BOTH get 20% OFF
• No limit on referrals!
• Plus earn points for future rewards

Your unique referral code: [CODE]
Just share with friends or send them this link: [Referral Link]

You're already amazing - now let's make your friends feel amazing too! 💕

[Your Business Name]`}],totalTouchpoints:3,duration:"3 weeks"}},{id:6,name:"Product Recommendations",description:"Share personalized product suggestions to boost retail sales",icon:F,color:"bg-secondary/20 border-secondary/40",iconColor:"text-primary",active:!1,clients:29,status:"Ready to activate",followUpDetails:{trigger:"Service-specific recommendations",timeline:[{time:"1 week after appointment",action:"Personalized product suggestions",frequency:"After qualifying services",message:`Hi [Name]! 💕 Hope you're still glowing from your [Service]!

Based on your service and skin/hair goals, I've curated some perfect products just for YOU:

✨ [Product 1] - Perfect for [specific benefit]
✨ [Product 2] - Will help maintain your [result]
✨ [Product 3] - Great for your [specific concern]

These aren't just recommendations - they're specifically chosen for YOUR unique needs! 🌟

💡 Want to chat about which would work best? Reply and let's discuss!

XOXO,
[Your Name]`},{time:"3 days later",action:"How-to tips for recommended products",frequency:"Once",message:`Hey gorgeous! 🌸 Ready to get the most out of those product recommendations?

Here are my pro tips for AMAZING results:

📋 [Product 1] Usage:
• When: [Timing]
• How: [Application method]
• Pro tip: [Special technique]

📋 [Product 2] Usage:
• When: [Timing]
• How: [Application method]
• Pro tip: [Special technique]

Remember: consistency is key for beautiful results! You've got this! 💪✨

[Your Business Name]`},{time:"1 week later",action:"Limited-time product discount",frequency:"Monthly",message:`Last chance, [Name]! 🛍️ Your personalized products are calling!

Special CLIENT-ONLY offer ending soon:

🎉 25% OFF all your recommended products
🎉 FREE shipping on orders over $50
🎉 Bonus sample of our newest arrival

Use code: VIP25
Expires: [Date] (3 days!)

💫 These products were chosen specifically for YOU - don't let them slip away!

🛒 Shop now: [Link]
📞 Call to order: [Phone]

Treat yourself - you deserve it! 💖

[Your Business Name]`}],totalTouchpoints:3,duration:"2 weeks"}},{id:7,name:"Loyalty / VIP Rewards",description:"Reward loyal clients with special perks and recognition",icon:y,active:!1,clients:42,status:"Ready to activate",followUpDetails:{trigger:"High-value clients (5+ appointments or $500+ spent)",timeline:[{time:"After qualifying for VIP status",action:"VIP welcome and benefits notification",frequency:"Once when qualifying",message:"🌟 CONGRATULATIONS [Name]! You're now a VIP client! 👑\\n\\nThanks for being such a loyal client! Your continued trust in us means everything. As our VIP, you now enjoy exclusive benefits:\\n\\n✨ 15% OFF all services\\n✨ Priority booking for your favorite times\\n✨ Complimentary add-ons (worth $25+)\\n✨ Birthday month special surprises\\n✨ First access to new services & products\\n\\nYour next visit earns you a complimentary [perk/reward]! Plus, every 3rd visit gets you a special treat! 🎁\\n\\nThank you for choosing us - you're absolutely amazing! 💖\\n\\n[Your Business Name] VIP Team"},{time:"Before each appointment",action:"VIP treatment reminder",frequency:"Every appointment",message:"Hey gorgeous VIP [Name]! 👑 Your appointment is coming up [Date/Time]!\\n\\nAs our valued VIP client, here's what's waiting for you:\\n\\n💎 Your 15% VIP discount is automatically applied\\n💎 Complimentary [specific add-on] included\\n💎 Reserved VIP parking spot #1\\n💎 Priority service with your favorite team member\\n\\nThis visit counts toward your loyalty rewards - you're [X] visits away from your next special surprise! 🎁\\n\\nWe can't wait to pamper you! See you soon! ✨\\n\\n[Your Business Name]"},{time:"After milestone visits (every 5th)",action:"Special milestone celebration",frequency:"Every 5 appointments",message:"🎉 MILESTONE CELEBRATION, [Name]! 🎉\\n\\nThis was your [X]th visit with us as a VIP client! You're absolutely incredible and we're so grateful for your loyalty! 💕\\n\\n🏆 Your milestone reward: [Special reward/service]\\n🏆 PLUS: Extra surprise treat is on us!\\n🏆 Next milestone at [X+5] visits = [Next reward]\\n\\nYou're not just a client - you're family! Thank you for trusting us with your beauty journey. Here's to many more gorgeous moments together! ✨\\n\\nWith endless gratitude,\\n[Your Business Name] Team 👑"}],totalTouchpoints:"Ongoing",duration:"Lifetime VIP status"}},{id:8,name:"Seasonal / Holiday Campaigns",description:"Drive bookings during peak seasons with timely promotions",icon:h,active:!0,clients:89,status:"Valentine's campaign running",followUpDetails:{trigger:"Seasonal periods (Valentine's, Summer, Holidays)",timeline:[{time:"6 weeks before peak season",action:"Early bird seasonal announcement",frequency:"3-4 times per year",message:"🌸 EARLY BIRD ALERT: [Season] glow-up season is coming! ✨\\n\\nHey beautiful [Name]! The most gorgeous time of year is almost here and we want to make sure you're absolutely RADIANT! 💫\\n\\n🎯 What's coming:\\n• [Season]-perfect treatments & services\\n• Limited seasonal packages\\n• Exclusive early bird pricing\\n• Prime appointment slots\\n\\n⏰ Early Bird Special (next 2 weeks only):\\n🌟 20% OFF all [seasonal services]\\n🌟 FREE seasonal add-on (worth $40)\\n🌟 Priority booking before general release\\n\\nDon't wait - spots fill up FAST during [season]! Reply YES to secure your glow-up! ✨\\n\\n[Your Business Name]"},{time:"4 weeks before peak season",action:"Urgency-driven booking push",frequency:"Seasonal peaks",message:"⚡ LAST CHANCE: [Season] glow-up spots filling FAST! ⚡\\n\\nHi gorgeous [Name]! Holiday glow-up season is here ✨ Book your spot before they're gone!\\n\\n🚨 ONLY 2 WEEKS LEFT of early pricing:\\n• [Service 1]: [X] spots remaining\\n• [Service 2]: [X] spots remaining\\n• [Popular Package]: 75% BOOKED\\n\\n💥 What you're missing if you wait:\\n❌ Prime weekend slots (almost gone!)\\n❌ 20% early bird discount\\n❌ Your favorite technician's availability\\n❌ The perfect timing for [holiday/event]\\n\\n📱 Quick booking: [Link] or reply NOW\\n⏰ Early bird pricing expires [Date]\\n\\nDon't let someone else take your glow-up slot! 🌟\\n\\n[Your Business Name]"},{time:"1 week before season ends",action:"Last chance seasonal offer",frequency:"End of each season",message:"⏰ FINAL WEEK: [Season] specials ending soon! ⏰\\n\\n[Name], our amazing [season] offers are almost over! Don't miss your chance to end this season looking absolutely stunning! 💖\\n\\n🎭 FINAL OPPORTUNITY:\\n• Last week for seasonal packages\\n• Final chance for [X]% OFF\\n• Only [X] appointment slots left\\n• Next availability: [Much later date]\\n\\n✨ Book this week and get:\\n🎁 Extra surprise add-on\\n🎁 Locked-in pricing for next season\\n🎁 VIP list for future early access\\n\\nThis is it - [season] magic ends [Date]! Secure your spot before we're fully booked! 🌟\\n\\n[Your Business Name]"}],totalTouchpoints:3,duration:"Seasonal cycles (3-4 per year)"}}],$=[{id:1,client:"Emma Rodriguez",action:"Received welcome message",time:"2 hours ago",type:"welcome"},{id:2,client:"Sophia Chen",action:"Responded to check-in",time:"4 hours ago",type:"checkin"},{id:3,client:"Maya Patel",action:"Used birthday discount",time:"1 day ago",type:"birthday"},{id:4,client:"Isabella Martinez",action:"Left 5-star review",time:"2 days ago",type:"review"}];function _(){const[l,j]=d.useState(p.reduce((s,n)=>(s[n.id]=n.active,s),{})),[t,c]=d.useState(null),[f,S]=d.useState({}),Y=s=>{j(n=>({...n,[s]:!n[s]}))},T=s=>{S(n=>({...n,[s]:!n[s]}))},A=Object.values(l).filter(Boolean).length,E=p.reduce((s,n)=>s+(l[n.id]?n.clients:0),0);return e.jsxs("div",{className:"space-y-8",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-3xl text-black mb-2",style:{fontFamily:"Playfair Display, serif"},children:"Follow Ups"}),e.jsx("p",{className:"text-lg text-muted-foreground",style:{fontFamily:"Montserrat, sans-serif"},children:"Stay connected with your clients automatically"})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:[e.jsx(a,{children:e.jsx(i,{className:"p-6",children:e.jsxs("div",{className:"flex items-center space-x-3",children:[e.jsx("div",{className:"p-3 bg-primary/10 rounded-full",children:e.jsx(g,{className:"h-6 w-6 text-primary"})}),e.jsxs("div",{children:[e.jsx("p",{className:"text-2xl font-bold text-black",children:A}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"Active Workflows"})]})]})})}),e.jsx(a,{children:e.jsx(i,{className:"p-6",children:e.jsxs("div",{className:"flex items-center space-x-3",children:[e.jsx("div",{className:"p-3 bg-accent/10 rounded-full",children:e.jsx(O,{className:"h-6 w-6 text-accent"})}),e.jsxs("div",{children:[e.jsx("p",{className:"text-2xl font-bold text-black",children:E}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"Clients Enrolled"})]})]})})}),e.jsx(a,{children:e.jsx(i,{className:"p-6",children:e.jsxs("div",{className:"flex items-center space-x-3",children:[e.jsx("div",{className:"p-3 bg-secondary/30 rounded-full",children:e.jsx(u,{className:"h-6 w-6 text-primary"})}),e.jsxs("div",{children:[e.jsx("p",{className:"text-2xl font-bold text-black",children:"$12.2K"}),e.jsx("p",{className:"text-sm text-muted-foreground",children:"Revenue This Month"})]})]})})})]}),e.jsxs(G,{defaultValue:"workflows",className:"w-full",children:[e.jsxs(X,{className:"grid w-full grid-cols-2 bg-secondary/10",children:[e.jsx(v,{value:"workflows",className:"data-[state=active]:bg-primary data-[state=active]:text-white",children:"My Workflows"}),e.jsx(v,{value:"activity",className:"data-[state=active]:bg-primary data-[state=active]:text-white",children:"Recent Activity"})]}),e.jsxs(w,{value:"workflows",className:"space-y-4",children:[e.jsx("div",{className:"space-y-4",children:p.map(s=>{const n=s.icon,r=l[s.id];return e.jsx(a,{className:`transition-all hover:shadow-sm ${r?"bg-primary/5 border-primary/20":"bg-accent/5 border-accent/20"}`,children:e.jsx(i,{className:"p-6",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center space-x-4",children:[e.jsx("div",{className:"p-3 bg-white rounded-full shadow-sm",children:e.jsx(n,{className:`h-6 w-6 ${r?"text-primary":"text-accent"}`})}),e.jsxs("div",{className:"flex-1",children:[e.jsxs("div",{className:"flex items-center space-x-3 mb-1",children:[e.jsx("h3",{className:"text-lg font-semibold text-black",style:{fontFamily:"Playfair Display, serif"},children:s.name}),r&&e.jsx(m,{className:"bg-green-100 text-green-700 border-green-200",children:"Active"})]}),e.jsx("p",{className:"text-muted-foreground mb-2",style:{fontFamily:"Montserrat, sans-serif"},children:s.description}),e.jsxs("div",{className:"flex items-center space-x-4 text-sm text-muted-foreground",children:[e.jsxs("span",{children:[s.clients," clients"]}),e.jsx("span",{children:"•"}),e.jsx("span",{children:s.status})]})]})]}),e.jsxs("div",{className:"flex items-center space-x-3",children:[e.jsxs(o,{variant:"outline",size:"sm",className:"text-sm",onClick:()=>c(s),children:[e.jsx(x,{className:"h-4 w-4 mr-1"}),"View Details"]}),e.jsxs("div",{className:"flex items-center space-x-2",children:[e.jsx("span",{className:"text-sm text-muted-foreground",children:r?"On":"Off"}),e.jsx(z,{checked:r,onCheckedChange:()=>Y(s.id)})]})]})]})})},s.id)})}),e.jsx(a,{className:"border-dashed border-2 border-primary/20",children:e.jsx(i,{className:"p-8 text-center",children:e.jsxs("div",{className:"flex flex-col items-center space-y-4",children:[e.jsx("div",{className:"p-4 bg-primary/10 rounded-full",children:e.jsx(I,{className:"h-8 w-8 text-primary"})}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold text-black mb-2",style:{fontFamily:"Playfair Display, serif"},children:"Need Something Custom?"}),e.jsx("p",{className:"text-muted-foreground mb-4",style:{fontFamily:"Montserrat, sans-serif"},children:"Contact our team to create custom workflows for your specific needs"}),e.jsx(o,{variant:"outline",className:"border-primary text-primary hover:bg-primary hover:text-white",children:"Get Help Setting Up"})]})]})})})]}),e.jsx(L,{open:!!t,onOpenChange:()=>c(null),children:e.jsxs(D,{className:"max-w-2xl max-h-[80vh] overflow-y-auto",children:[e.jsxs(W,{children:[e.jsx(q,{className:"flex items-center space-x-3",children:t&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:`p-3 rounded-full ${t.color}`,children:e.jsx(t.icon,{className:`h-6 w-6 ${t.iconColor}`})}),e.jsx("div",{children:e.jsx("h3",{style:{fontFamily:"Playfair Display, serif"},children:t.name})})]})}),e.jsx(U,{children:t?.description||"View workflow details and configuration"})]}),t&&e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"grid grid-cols-3 gap-4",children:[e.jsxs("div",{className:"text-center p-4 bg-primary/5 rounded-lg border border-primary/20",children:[e.jsx("div",{className:"text-2xl font-bold text-primary",children:t.followUpDetails.totalTouchpoints}),e.jsx("div",{className:"text-sm text-muted-foreground",children:"Messages"})]}),e.jsxs("div",{className:"text-center p-4 bg-accent/5 rounded-lg border border-accent/20",children:[e.jsx("div",{className:"text-2xl font-bold text-accent",children:t.followUpDetails.duration}),e.jsx("div",{className:"text-sm text-muted-foreground",children:"Duration"})]}),e.jsxs("div",{className:"text-center p-4 bg-secondary/20 rounded-lg border border-secondary/40",children:[e.jsx("div",{className:"text-2xl font-bold text-black",children:t.clients}),e.jsx("div",{className:"text-sm text-muted-foreground",children:"Clients"})]})]}),e.jsxs("div",{className:"p-4 bg-primary/5 rounded-lg border border-primary/20",children:[e.jsxs("div",{className:"flex items-center space-x-2 mb-2",children:[e.jsx(P,{className:"h-4 w-4 text-primary"}),e.jsx("span",{className:"font-semibold text-black",children:"Workflow Trigger"})]}),e.jsx("p",{className:"text-muted-foreground",style:{fontFamily:"Montserrat, sans-serif"},children:t.followUpDetails.trigger})]}),e.jsxs("div",{children:[e.jsxs("h4",{className:"font-semibold text-black mb-4 flex items-center space-x-2",children:[e.jsx(b,{className:"h-4 w-4 text-primary"}),e.jsx("span",{children:"Follow-up Timeline"}),e.jsx("span",{className:"text-sm text-muted-foreground font-normal",children:"(Click steps to see exact messages)"})]}),e.jsx("div",{className:"space-y-4",children:t.followUpDetails.timeline.map((s,n)=>e.jsxs("div",{className:"border rounded-lg bg-card overflow-hidden",children:[e.jsxs("div",{className:"flex items-start space-x-4 p-4 cursor-pointer hover:bg-muted/20 transition-colors",onClick:()=>T(n),children:[e.jsx("div",{className:"flex-shrink-0 w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center",children:e.jsx("span",{className:"text-sm font-semibold text-primary",children:n+1})}),e.jsxs("div",{className:"flex-1",children:[e.jsxs("div",{className:"flex items-center space-x-2 mb-1",children:[e.jsx(R,{className:"h-4 w-4 text-accent"}),e.jsx("span",{className:"font-medium text-black",children:s.time}),e.jsx(m,{className:"bg-secondary/20 text-black border-secondary/40 text-xs",children:s.frequency})]}),e.jsxs("div",{className:"flex items-start space-x-2",children:[e.jsx(H,{className:"h-4 w-4 text-muted-foreground mt-0.5"}),e.jsx("p",{className:"text-muted-foreground",style:{fontFamily:"Montserrat, sans-serif"},children:s.action})]})]}),e.jsx("div",{className:"flex-shrink-0",children:e.jsx(x,{className:`h-4 w-4 transition-transform ${f[n]?"rotate-180":""} text-primary`})})]}),f[n]&&e.jsxs("div",{className:"border-t bg-muted/10 p-4",children:[e.jsxs("div",{className:"flex items-center space-x-2 mb-3",children:[e.jsx(B,{className:"h-4 w-4 text-accent"}),e.jsx("span",{className:"font-medium text-black",children:"Exact Message:"})]}),e.jsx("div",{className:"bg-white rounded-lg p-4 border border-primary/20",children:e.jsx("p",{className:"text-sm text-black whitespace-pre-line",style:{fontFamily:"Montserrat, sans-serif"},children:s.message})}),e.jsxs("div",{className:"mt-3 flex items-center justify-between text-xs text-muted-foreground",children:[e.jsx("span",{children:"Message will be automatically personalized with client details"}),e.jsx(m,{variant:"outline",className:"text-xs",children:"Proven Template"})]})]})]},n))})]}),e.jsxs("div",{className:"flex justify-between items-center pt-4 border-t",children:[e.jsx(o,{variant:"outline",onClick:()=>c(null),children:"Close"}),e.jsxs("div",{className:"flex space-x-2",children:[e.jsxs(o,{variant:"outline",className:"border-accent text-accent hover:bg-accent hover:text-white",children:[e.jsx(u,{className:"h-4 w-4 mr-2"}),"View Results"]}),e.jsxs(o,{className:"bg-primary hover:bg-primary/90",children:[e.jsx(g,{className:"h-4 w-4 mr-2"}),l[t.id]?"View Analytics":"Activate Workflow"]})]})]})]})]})}),e.jsx(w,{value:"activity",className:"space-y-4",children:e.jsxs(a,{children:[e.jsx(M,{children:e.jsxs(V,{className:"flex items-center space-x-2",children:[e.jsx(b,{className:"h-5 w-5 text-primary"}),e.jsx("span",{children:"What's Happening"})]})}),e.jsxs(i,{children:[e.jsx("div",{className:"space-y-4",children:$.map(s=>e.jsxs("div",{className:"flex items-center justify-between p-4 rounded-lg bg-muted/30",children:[e.jsxs("div",{className:"flex items-center space-x-3",children:[e.jsxs("div",{className:"w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center",children:[s.type==="welcome"&&e.jsx(N,{className:"h-4 w-4 text-primary"}),s.type==="checkin"&&e.jsx(k,{className:"h-4 w-4 text-accent"}),s.type==="birthday"&&e.jsx(h,{className:"h-4 w-4 text-primary"}),s.type==="review"&&e.jsx(y,{className:"h-4 w-4 text-accent"})]}),e.jsxs("div",{children:[e.jsx("p",{className:"font-medium text-black",children:s.client}),e.jsx("p",{className:"text-sm text-muted-foreground",children:s.action})]})]}),e.jsx("span",{className:"text-sm text-muted-foreground",children:s.time})]},s.id))}),e.jsxs("div",{className:"text-center py-8 border-t mt-6",children:[e.jsx("p",{className:"text-muted-foreground mb-4",children:"Activity will appear here as your workflows run"}),e.jsxs(o,{variant:"outline",size:"sm",children:[e.jsx(u,{className:"h-4 w-4 mr-2"}),"View Full Analytics"]})]})]})]})})]})]})}export{_ as FollowUps};
